// asset/config.js

module.exports = {
  token:
    "MTIyNjUxMDk4NzQwNzEzMDYyNA.GARrEe.fQqog3WSEHeCxguUG9lXiHniDWQqk6xJ-Hg5IY", // Your Discord bot toke
  clientId: "1226510987407130624", // Your Discord application's client ID
  prefix: "-", // Default prefix for commands
  mongoURI:
    "mongodb+srv://godkode:noprefix@cluster0.mmfongd.mongodb.net/?retryWrites=true&w=majorit", // Your MongoDB connection URI
  owner: "761102755107438594", // Bot owner's Discord ID
  lavalink: [
    {
      name: "Ajie Dev Node",
      url: "lava-v4.ajieblogs.eu.org:80", // host:port format
      auth: "https://dsc.gg/ajidevserver",
      secure: false,
    },
  ],
  spotify: {
    clientId: "7b9f0aeabd3f485ab19027c516ae2c8f",
    clientSecret: "222507c6638b4244a4856c0ddf8a3d66",
  },
};
