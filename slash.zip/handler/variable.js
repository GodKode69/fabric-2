// handler/variable.js

function initVariables(client) {
  client.variables = {
    color: "#2c2f3", // Default embed color
    footer: "Fabric | Made By GodKode.", // Default embed footer
  };
}

module.exports = { initVariables };
