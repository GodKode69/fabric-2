// asset/config.js

module.exports = {
  token:
    "MTIyNjUxMDk4NzQwNzEzMDYyNA.GwiJkt.XOxJZ9GK_iYJbEu7LFbauC_id_9I644ywaPFJA", // Your Discord bot toke
  clientId: "1226510987407130624", // Your Discord application's client ID
  prefix: "-", // Default prefix for commands
  mongoURI:
    "mongodb+srv://godkode:noprefix@cluster0.mmfongd.mongodb.net/?retryWrites=true&w=majorit", // Your MongoDB connection URI
  owner: "761102755107438594", // Bot owner's Discord ID
};
