/*

  chatbot: {
    channelId: {
      type: String,
    },
    persona: {
      type: String,
    },
  },
  autoresponses: {
    trigger: {
      type: String,
    },
    response: {
      type: String,
    },
  },
  autoreaction: {
    trigger: {
      type: String,
    },
    reaction: {
      type: String,
    },
  },
  ignore: {
    channelId: {
      type: String,
    },
    ignore: {
      type: Boolean,
      default: true,
    },
  },
  */